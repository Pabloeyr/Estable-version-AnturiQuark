# Primera actualizacion por USB-C del Anturi Quark. Windows 10 u 11.
# Prepara el equipo para recibir las siguientes actualizaciones desde la app.
param(
    [string]$Esptool = "",
    [string]$Port = ""
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$FirmwareDir = Join-Path $Root "firmware"
$BackupDir = Join-Path $Root "respaldos"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile = Join-Path $Root "registro_$Stamp.txt"
if ($Esptool -eq "") { $Esptool = Join-Path $Root "herramientas\esptool.exe" }

$AppOffset = 0x10000
$HeadSize = 0x100
$BackupSize = 0x200000
$RequiredFlashMB = 4
$AppDescMagic = [uint32]2882360370   # 0xABCD5432

# El registro queda abierto todo el proceso y comparte lectura/escritura: un antivirus o una
# carpeta sincronizada (OneDrive, Google Drive) que lo abra no puede cortar la actualizacion.
$script:LogWriter = $null
function Open-Log {
    try {
        $stream = [IO.File]::Open($LogFile, [IO.FileMode]::Append, [IO.FileAccess]::Write,
                                  [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
        $script:LogWriter = New-Object IO.StreamWriter($stream, (New-Object Text.UTF8Encoding $false))
        $script:LogWriter.AutoFlush = $true
    } catch {
        $script:LogWriter = $null
    }
}

function Write-Log([string]$Text) {
    if ($null -eq $script:LogWriter) { return }
    try { $script:LogWriter.WriteLine($Text) } catch { }
}

function Say([string]$Es, [string]$En) {
    Write-Host $Es
    Write-Host "  $En" -ForegroundColor DarkGray
    Write-Log $Es
}

function Stop-Update([string]$Es, [string]$En) {
    Write-Host ""
    Write-Host "NO SE COMPLETO / NOT COMPLETED" -ForegroundColor Red
    Say $Es $En
    Write-Host ""
    Write-Host "Registro / Log: $LogFile"
    exit 1
}

function Invoke-Esptool([string[]]$Arguments, [string]$FailEs, [string]$FailEn) {
    Write-Log ("> esptool " + ($Arguments -join " "))
    $previous = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $output = & $Esptool @Arguments 2>&1 | ForEach-Object { "$_" }
    $code = $LASTEXITCODE
    $ErrorActionPreference = $previous
    $output | ForEach-Object { Write-Log $_ }
    if ($code -ne 0) { Stop-Update $FailEs $FailEn }
    return $output
}

function Test-Esptool([string[]]$Arguments) {
    Write-Log ("> esptool " + ($Arguments -join " "))
    $previous = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    & $Esptool @Arguments 2>&1 | ForEach-Object { Write-Log "$_" }
    $code = $LASTEXITCODE
    $ErrorActionPreference = $previous
    return ($code -eq 0)
}

function Restart-Quark {
    [void](Invoke-Esptool @("--chip", "esp32c6", "--port", $Port, "--before", "default_reset",
                            "--after", "hard_reset", "chip_id") $failConnectEs $failConnectEn)
}

function Test-OtaDataUsed([string]$ComPort) {
    $file = Join-Path $env:TEMP "quark_otadata_$Stamp.bin"
    [void](Invoke-Esptool @("--chip", "esp32c6", "--port", $ComPort, "--before", "default_reset",
                            "--after", "no_reset", "read_flash", "0x3D0000", "0x40", $file) `
        "No se pudo leer el estado del equipo." "Could not read the device state.")
    $bytes = [IO.File]::ReadAllBytes($file)
    Remove-Item $file -Force -ErrorAction SilentlyContinue
    return @($bytes | Where-Object { $_ -ne 0xFF }).Count -gt 0
}

function Find-QuarkPort {
    $devices = @(Get-CimInstance Win32_PnPEntity |
        Where-Object { $_.PNPDeviceID -match "VID_303A&PID_1001" -and $_.Name -match "\((COM\d+)\)" })
    if ($devices.Count -eq 0) {
        Stop-Update "No se encontro el Quark. Enciendelo, conectalo por USB-C con un cable de datos y vuelve a intentar." `
                    "Quark not found. Turn it on, connect it with a USB-C data cable and try again."
    }
    if ($devices.Count -gt 1) {
        Stop-Update "Hay mas de un equipo conectado. Deja conectado solo un Quark." `
                    "More than one device is connected. Leave only one Quark connected."
    }
    [void]($devices[0].Name -match "\((COM\d+)\)")
    return $Matches[1]
}

function Read-Ascii([byte[]]$Bytes, [int]$Offset, [int]$Length) {
    $end = $Offset
    while ($end -lt ($Offset + $Length) -and $Bytes[$end] -ne 0) { $end++ }
    return [Text.Encoding]::ASCII.GetString($Bytes, $Offset, $end - $Offset)
}

function Read-InstalledApp([string]$ComPort) {
    $file = Join-Path $env:TEMP "quark_head_$Stamp.bin"
    [void](Invoke-Esptool @("--chip", "esp32c6", "--port", $ComPort, "--before", "default_reset",
                            "--after", "no_reset", "read_flash",
                            ("0x{0:X}" -f $AppOffset), ("0x{0:X}" -f $HeadSize), $file) `
        "No se pudo leer el firmware instalado." "Could not read the installed firmware.")
    $bytes = [IO.File]::ReadAllBytes($file)
    Remove-Item $file -Force -ErrorAction SilentlyContinue
    if ($bytes.Length -lt $HeadSize -or $bytes[0] -ne 0xE9 -or
        [BitConverter]::ToUInt32($bytes, 0x20) -ne $AppDescMagic) {
        return $null
    }
    return @{ Version = (Read-Ascii $bytes 0x30 32); Project = (Read-Ascii $bytes 0x50 32) }
}

Open-Log
Write-Log "Quark USB update $Stamp"

$manifestPath = Join-Path $FirmwareDir "firmware.json"
if (-not (Test-Path $Esptool) -or -not (Test-Path $manifestPath)) {
    Stop-Update "Faltan archivos. Descomprime toda la carpeta antes de ejecutar." `
                "Files are missing. Extract the whole folder first."
}
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
$target = [string]$manifest.version
$hardwarePrefix = $target.Substring(0, $target.LastIndexOf(".") + 1)

Write-Host ""
Write-Host "Anturi Quark - actualizacion USB $target" -ForegroundColor Cyan
Write-Host "No desconectes ni apagues el Quark hasta que termine." -ForegroundColor Yellow
Write-Host "Do not disconnect or turn off the Quark until it finishes." -ForegroundColor DarkGray
Write-Host ""

$flashArgs = @()
foreach ($item in $manifest.archivos.PSObject.Properties) {
    $path = Join-Path $FirmwareDir $item.Value.archivo
    if (-not (Test-Path $path) -or
        (Get-FileHash $path -Algorithm SHA256).Hash.ToLower() -ne $item.Value.sha256) {
        Stop-Update "Los archivos del firmware estan danados. Descarga el paquete otra vez." `
                    "The firmware files are damaged. Download the package again."
    }
    $flashArgs += @($item.Name, $path)
}

if ($Port -eq "") { $Port = Find-QuarkPort }
Say "1/4 Quark encontrado en $Port. Revisando el equipo..." "Quark found on $Port. Checking the device..."

$failConnectEs = "No se pudo comunicar con el Quark. Revisa que este encendido y prueba otro cable o puerto USB."
$failConnectEn = "Could not talk to the Quark. Check that it is on and try another cable or USB port."
$info = Invoke-Esptool @("--chip", "esp32c6", "--port", $Port, "--before", "default_reset",
                         "--after", "no_reset", "flash_id") $failConnectEs $failConnectEn
$text = $info -join "`n"
if ($text -notmatch "Detected flash size:\s*(\d+)MB" -or [int]$Matches[1] -lt $RequiredFlashMB) {
    Stop-Update "Este equipo no tiene la memoria necesaria ($RequiredFlashMB MB). No se modifico nada." `
                "This device does not have the required memory ($RequiredFlashMB MB). Nothing was changed."
}
$mac = "desconocido"
if ($text -match "MAC:\s*([0-9a-fA-F:]+)") { $mac = $Matches[1].Replace(":", "") }

$connection = @("--chip", "esp32c6", "--port", $Port, "--before", "default_reset", "--after", "no_reset")
$flashOptions = @("--flash_mode", "dio", "--flash_freq", "80m", "--flash_size", "keep")
$tablePath = Join-Path $FirmwareDir $manifest.archivos."0x8000".archivo
$resuming = $false

# La tabla de particiones nueva se graba primero: si ya esta, el equipo fue preparado
# antes o una grabacion anterior se interrumpio.
if (Test-Esptool ($connection + @("verify_flash") + $flashOptions + @("0x8000", $tablePath))) {
    if (Test-Esptool ($connection + @("verify_flash") + $flashOptions + $flashArgs)) {
        Restart-Quark
        Say "Este Quark ya tiene la version $target. No hay nada que hacer." `
            "This Quark already has version $target. Nothing to do."
        exit 0
    }
    if (Test-OtaDataUsed $Port) {
        Restart-Quark
        Say "Este Quark ya esta habilitado. Actualizalo desde la app." `
            "This Quark is already enabled. Update it from the app."
        exit 0
    }
    $resuming = $true
    Say "Se detecto una grabacion incompleta. Se retomara." "An incomplete update was found. Resuming."
} else {
    $installed = Read-InstalledApp $Port
    if ($null -eq $installed -or $installed.Project -ne "ESP32C6") {
        Stop-Update "El firmware instalado no se reconoce como Anturi Quark. No se modifico nada." `
                    "The installed firmware is not recognized as Anturi Quark. Nothing was changed."
    }
    Write-Log "Instalado: $($installed.Version)"
    if ($installed.Version -match "^\d+\.\d+\.\d+$" -and -not $installed.Version.StartsWith($hardwarePrefix)) {
        Stop-Update "Este paquete es para otra revision de hardware. No se modifico nada." `
                    "This package is for another hardware revision. Nothing was changed."
    }
}

if (-not $resuming) {
    Say "2/4 Guardando un respaldo del firmware actual..." "Saving a backup of the current firmware..."
    New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
    $backup = Join-Path $BackupDir "Quark_${mac}_$Stamp.bin"
    [void](Invoke-Esptool @("--chip", "esp32c6", "--port", $Port, "--baud", "460800",
                            "--before", "default_reset", "--after", "no_reset", "read_flash",
                            "0x0", ("0x{0:X}" -f $BackupSize), $backup) `
        "No se pudo guardar el respaldo. No se modifico nada." "Could not save the backup. Nothing was changed.")
}

Say "3/4 Grabando el firmware nuevo..." "Writing the new firmware..."
$write = @("--chip", "esp32c6", "--port", $Port, "--baud", "460800", "--before", "default_reset",
           "--after", "no_reset", "write_flash", "--flash_mode", "dio", "--flash_freq", "80m",
           "--flash_size", "keep") + $flashArgs
[void](Invoke-Esptool $write `
    "La grabacion se interrumpio. Deja el Quark conectado y ejecuta este programa otra vez." `
    "Writing was interrupted. Keep the Quark connected and run this program again.")

Say "4/4 Comprobando..." "Checking..."
$result = Read-InstalledApp $Port
if ($null -eq $result -or $result.Version -ne $target) {
    Stop-Update "La comprobacion fallo. Ejecuta este programa otra vez." `
                "The check failed. Run this program again."
}
Restart-Quark

Write-Host ""
Write-Host "LISTO / DONE" -ForegroundColor Green
Say "El Quark quedo con la version $target. Las proximas actualizaciones se hacen desde la app." `
    "The Quark now has version $target. Future updates are done from the app."
Write-Host "Registro / Log: $LogFile"
exit 0
