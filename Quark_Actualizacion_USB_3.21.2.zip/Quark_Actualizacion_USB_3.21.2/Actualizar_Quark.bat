@echo off
title Anturi Quark - Actualizacion USB
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0actualizar_quark.ps1"
echo.
pause
