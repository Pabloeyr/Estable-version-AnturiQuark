#!/usr/bin/env bash
# Primera actualizacion por USB-C del Anturi Quark en Linux x86-64.
# Prepara el equipo para recibir las siguientes actualizaciones desde la app.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIRMWARE_DIR="$ROOT/firmware"
BACKUP_DIR="$ROOT/respaldos"
STAMP="$(date +%Y%m%d_%H%M%S)"
LOG_FILE="$ROOT/registro_$STAMP.txt"
ESPTOOL="$ROOT/herramientas/linux/esptool"
PORT=""
REQUIRED_FLASH_MB=4
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT

while [ $# -gt 0 ]; do
    case "$1" in
        --esptool) ESPTOOL="$2"; shift 2 ;;
        --port) PORT="$2"; shift 2 ;;
        *) shift ;;
    esac
done

echo "Quark USB update $STAMP" > "$LOG_FILE"

say() {
    echo "$1"
    echo "  $2"
    echo "$1" >> "$LOG_FILE"
}

stop_update() {
    echo
    echo "NO SE COMPLETO / NOT COMPLETED"
    say "$1" "$2"
    echo
    echo "Registro / Log: $LOG_FILE"
    exit 1
}

try_esptool() {
    echo "> esptool $*" >> "$LOG_FILE"
    "$ESPTOOL" "$@" >> "$LOG_FILE" 2>&1
}

need_esptool() {
    local fail_es="$1" fail_en="$2"
    shift 2
    try_esptool "$@" || stop_update "$fail_es" "$fail_en"
}

FAIL_CONNECT_ES="No se pudo comunicar con el Quark. Revisa que este encendido y prueba otro cable o puerto USB."
FAIL_CONNECT_EN="Could not talk to the Quark. Check that it is on and try another cable or USB port."

find_port() {
    local found=() tty vendor
    for tty in /sys/class/tty/ttyACM*; do
        [ -e "$tty/device/../idVendor" ] || continue
        vendor="$(cat "$tty/device/../idVendor")"
        [ "$vendor" = "303a" ] && found+=("/dev/$(basename "$tty")")
    done
    if [ "${#found[@]}" -eq 0 ]; then
        stop_update "No se encontro el Quark. Enciendelo, conectalo por USB-C con un cable de datos y vuelve a intentar." \
                    "Quark not found. Turn it on, connect it with a USB-C data cable and try again."
    fi
    if [ "${#found[@]}" -gt 1 ]; then
        stop_update "Hay mas de un equipo conectado. Deja conectado solo un Quark." \
                    "More than one device is connected. Leave only one Quark connected."
    fi
    PORT="${found[0]}"
    if [ ! -r "$PORT" ] || [ ! -w "$PORT" ]; then
        local group
        group="$(stat -c %G "$PORT")"
        stop_update "Sin permiso para usar $PORT. Ejecuta: sudo usermod -aG $group \$USER . Luego cierra sesion, vuelve a entrar y repite." \
                    "No permission for $PORT. Run: sudo usermod -aG $group \$USER . Then log out, log back in and retry."
    fi
}

bytes_hex() {  # archivo offset cantidad
    od -An -tx1 -j "$2" -N "$3" "$1" | tr -d ' \n'
}

text_at() {  # archivo offset cantidad
    dd if="$1" bs=1 skip="$2" count="$3" 2>/dev/null | tr -d '\000'
}

INSTALLED_VERSION=""
INSTALLED_PROJECT=""
read_installed_app() {
    local file="$WORK_DIR/head.bin"
    need_esptool "No se pudo leer el firmware instalado." "Could not read the installed firmware." \
        "${CONNECTION[@]}" read_flash 0x10000 0x100 "$file"
    INSTALLED_VERSION=""
    INSTALLED_PROJECT=""
    [ "$(bytes_hex "$file" 0 1)" = "e9" ] || return 1
    [ "$(bytes_hex "$file" 32 4)" = "3254cdab" ] || return 1
    INSTALLED_VERSION="$(text_at "$file" 48 32)"
    INSTALLED_PROJECT="$(text_at "$file" 80 32)"
    return 0
}

ota_data_used() {
    local file="$WORK_DIR/otadata.bin"
    need_esptool "No se pudo leer el estado del equipo." "Could not read the device state." \
        "${CONNECTION[@]}" read_flash 0x3D0000 0x40 "$file"
    [ -n "$(od -An -tx1 -v "$file" | tr -d ' \n' | sed 's/ff//g')" ]
}

restart_quark() {
    need_esptool "$FAIL_CONNECT_ES" "$FAIL_CONNECT_EN" \
        --chip esp32c6 --port "$PORT" --before default_reset --after hard_reset chip_id
}

MANIFEST="$FIRMWARE_DIR/firmware.lst"
if [ ! -f "$ESPTOOL" ] || [ ! -f "$MANIFEST" ]; then
    stop_update "Faltan archivos. Descomprime toda la carpeta antes de ejecutar." \
                "Files are missing. Extract the whole folder first."
fi
chmod +x "$ESPTOOL" 2>/dev/null

TARGET=""
FLASH_ARGS=()
TABLE_PATH=""
while read -r offset name hash; do
    if [ "$offset" = "version" ]; then
        TARGET="$name"
        continue
    fi
    path="$FIRMWARE_DIR/$name"
    if [ ! -f "$path" ] || [ "$(sha256sum "$path" | cut -d' ' -f1)" != "$hash" ]; then
        stop_update "Los archivos del firmware estan danados. Descarga el paquete otra vez." \
                    "The firmware files are damaged. Download the package again."
    fi
    FLASH_ARGS+=("$offset" "$path")
    [ "$offset" = "0x8000" ] && TABLE_PATH="$path"
done < <(tr -d '\r' < "$MANIFEST")
HARDWARE_PREFIX="${TARGET%.*}."

echo
echo "Anturi Quark - actualizacion USB $TARGET"
echo "No desconectes ni apagues el Quark hasta que termine."
echo "Do not disconnect or turn off the Quark until it finishes."
echo

[ -n "$PORT" ] || find_port
say "1/4 Quark encontrado en $PORT. Revisando el equipo..." "Quark found on $PORT. Checking the device..."

CONNECTION=(--chip esp32c6 --port "$PORT" --before default_reset --after no_reset)
FLASH_OPTIONS=(--flash_mode dio --flash_freq 80m --flash_size keep)

echo "> esptool flash_id" >> "$LOG_FILE"
INFO="$("$ESPTOOL" "${CONNECTION[@]}" flash_id 2>&1)" || {
    echo "$INFO" >> "$LOG_FILE"
    stop_update "$FAIL_CONNECT_ES" "$FAIL_CONNECT_EN"
}
echo "$INFO" >> "$LOG_FILE"
FLASH_MB="$(echo "$INFO" | sed -n 's/.*Detected flash size: *\([0-9][0-9]*\)MB.*/\1/p' | head -n 1)"
if [ -z "$FLASH_MB" ] || [ "$FLASH_MB" -lt "$REQUIRED_FLASH_MB" ]; then
    stop_update "Este equipo no tiene la memoria necesaria ($REQUIRED_FLASH_MB MB). No se modifico nada." \
                "This device does not have the required memory ($REQUIRED_FLASH_MB MB). Nothing was changed."
fi
MAC="$(echo "$INFO" | sed -n 's/^MAC: *\([0-9a-fA-F:]*\).*/\1/p' | head -n 1 | tr -d ':')"
[ -n "$MAC" ] || MAC="desconocido"

RESUMING=0
# La tabla de particiones nueva se graba primero: si ya esta, el equipo fue preparado
# antes o una grabacion anterior se interrumpio.
if try_esptool "${CONNECTION[@]}" verify_flash "${FLASH_OPTIONS[@]}" 0x8000 "$TABLE_PATH"; then
    if try_esptool "${CONNECTION[@]}" verify_flash "${FLASH_OPTIONS[@]}" "${FLASH_ARGS[@]}"; then
        restart_quark
        say "Este Quark ya tiene la version $TARGET. No hay nada que hacer." \
            "This Quark already has version $TARGET. Nothing to do."
        exit 0
    fi
    if ota_data_used; then
        restart_quark
        say "Este Quark ya esta habilitado. Actualizalo desde la app." \
            "This Quark is already enabled. Update it from the app."
        exit 0
    fi
    RESUMING=1
    say "Se detecto una grabacion incompleta. Se retomara." "An incomplete update was found. Resuming."
else
    if ! read_installed_app || [ "$INSTALLED_PROJECT" != "ESP32C6" ]; then
        stop_update "El firmware instalado no se reconoce como Anturi Quark. No se modifico nada." \
                    "The installed firmware is not recognized as Anturi Quark. Nothing was changed."
    fi
    echo "Instalado: $INSTALLED_VERSION" >> "$LOG_FILE"
    if [[ "$INSTALLED_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$INSTALLED_VERSION" != "$HARDWARE_PREFIX"* ]]; then
        stop_update "Este paquete es para otra revision de hardware. No se modifico nada." \
                    "This package is for another hardware revision. Nothing was changed."
    fi
fi

if [ "$RESUMING" -eq 0 ]; then
    say "2/4 Guardando un respaldo del firmware actual..." "Saving a backup of the current firmware..."
    mkdir -p "$BACKUP_DIR"
    need_esptool "No se pudo guardar el respaldo. No se modifico nada." "Could not save the backup. Nothing was changed." \
        --chip esp32c6 --port "$PORT" --baud 460800 --before default_reset --after no_reset \
        read_flash 0x0 0x200000 "$BACKUP_DIR/Quark_${MAC}_$STAMP.bin"
fi

say "3/4 Grabando el firmware nuevo..." "Writing the new firmware..."
need_esptool "La grabacion se interrumpio. Deja el Quark conectado y ejecuta este programa otra vez." \
             "Writing was interrupted. Keep the Quark connected and run this program again." \
    --chip esp32c6 --port "$PORT" --baud 460800 --before default_reset --after no_reset \
    write_flash "${FLASH_OPTIONS[@]}" "${FLASH_ARGS[@]}"

say "4/4 Comprobando..." "Checking..."
if ! read_installed_app || [ "$INSTALLED_VERSION" != "$TARGET" ]; then
    stop_update "La comprobacion fallo. Ejecuta este programa otra vez." "The check failed. Run this program again."
fi
restart_quark

echo
echo "LISTO / DONE"
say "El Quark quedo con la version $TARGET. Las proximas actualizaciones se hacen desde la app." \
    "The Quark now has version $TARGET. Future updates are done from the app."
echo "Registro / Log: $LOG_FILE"
exit 0
